import {Course} from './course'
export let courses: Course[] = [
    {
      courseName:".NET",
      courseDuration:"5"
    },
    {
      courseName:"EcmaScript",
      courseDuration:"8"
    },
    {
      courseName:"Java",
      courseDuration:"7"
    },
    {
      courseName:"MySQL",
      courseDuration:"6"
    }
  ];