function dispHello()
{
	document.write("Hello World");
}