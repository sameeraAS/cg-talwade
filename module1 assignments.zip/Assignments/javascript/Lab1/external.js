var company="capgemini";
window.document.write("<font color='red'>Welcome to :</font>");
window.document.write(company);